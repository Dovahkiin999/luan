/**
 * 针对ClassPath和文件中资源读取的封装，主要入口为工具类ResourceUtil
 * 
 * @author looly
 *
 */
package cn.hutool.core.io.resource;