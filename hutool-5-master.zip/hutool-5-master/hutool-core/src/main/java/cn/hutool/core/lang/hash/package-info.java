/**
 * 提供Hash算法的封装
 * 
 * @author looly
 *
 */
package cn.hutool.core.lang.hash;