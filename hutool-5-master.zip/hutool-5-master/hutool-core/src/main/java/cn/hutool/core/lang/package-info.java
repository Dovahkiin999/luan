/**
 * 语言特性包，包括大量便捷的数据结构，例如验证器Validator，分布式ID生成器Snowflake等
 * 
 * @author looly
 *
 */
package cn.hutool.core.lang;