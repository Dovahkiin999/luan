/**
 * 拷贝抽象实现，通过抽象拷贝，可以实现文件、流、Buffer之间的拷贝实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.lang.copier;