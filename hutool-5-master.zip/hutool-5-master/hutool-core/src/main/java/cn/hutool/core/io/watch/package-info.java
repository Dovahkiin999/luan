/**
 * 基于JDK7+ WatchService的文件和目录监听封装，支持多级目录
 * 
 * @author looly
 *
 */
package cn.hutool.core.io.watch;