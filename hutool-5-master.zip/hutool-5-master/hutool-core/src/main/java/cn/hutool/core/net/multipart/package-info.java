/**
 * 文件上传封装
 * 
 * @author looly
 *
 */
package cn.hutool.core.net.multipart;