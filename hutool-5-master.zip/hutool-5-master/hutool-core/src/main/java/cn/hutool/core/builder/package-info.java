/**
 * 建造者工具<br>
 * 用于建造特定对象或结果
 * 
 * @author looly
 *
 */
package cn.hutool.core.builder;