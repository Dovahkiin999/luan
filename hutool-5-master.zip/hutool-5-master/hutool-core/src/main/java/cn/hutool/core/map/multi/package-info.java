/**
 * 列表类型值的Map实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.map.multi;