/**
 * 剪贴板相关的工具，包括剪贴板监听等
 * 
 * @author looly
 *
 */
package cn.hutool.core.swing.clipboard;