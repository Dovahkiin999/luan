/**
 * Hutool核心方法及数据结构包
 * 
 * @author looly
 *
 */
package cn.hutool.core;