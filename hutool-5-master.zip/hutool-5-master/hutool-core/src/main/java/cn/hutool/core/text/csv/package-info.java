/**
 * 提供CSV文件读写的封装，入口为CsvUtil
 * 
 * @author looly
 *
 */
package cn.hutool.core.text.csv;