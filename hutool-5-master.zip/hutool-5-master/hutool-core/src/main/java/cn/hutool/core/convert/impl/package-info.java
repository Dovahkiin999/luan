/**
 * 各种类型转换的实现类，其都为Converter接口的实现，用于将未知的Object类型转换为指定类型
 * 
 * @author looly
 *
 */
package cn.hutool.core.convert.impl;