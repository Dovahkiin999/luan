/**
 * URL相关工具
 * 
 * @author looly
 * @since 5.3.1
 */
package cn.hutool.core.net.url;