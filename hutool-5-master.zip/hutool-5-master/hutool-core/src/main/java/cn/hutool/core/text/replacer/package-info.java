/**
 * 文本替换类抽象及实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.text.replacer;