/**
 * JDK动态代理封装，提供非IOC下的切面支持
 * 
 * @author looly
 *
 */
package cn.hutool.aop;