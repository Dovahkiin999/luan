/**
 * 各种Hash算法的过滤器实现
 * 
 * @author looly
 *
 */
package cn.hutool.bloomfilter.filter;